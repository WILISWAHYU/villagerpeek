package com.wiliz.villagerpeek.mixin.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.screens.inventory.MerchantScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.MerchantMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.trading.MerchantOffer;
import net.minecraft.world.item.trading.MerchantOffers;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MerchantScreen.class)
public abstract class MerchantScreenMixin extends AbstractContainerScreen<MerchantMenu> {

    public MerchantScreenMixin(MerchantMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void renderAllTradesOverlay(GuiGraphics graphics, int mouseX, int mouseY, float partialTick, CallbackInfo ci) {
        MerchantOffers offers = this.menu.getOffers();
        if (offers == null || offers.isEmpty()) {
            return;
        }

        int startX = this.leftPos + this.imageWidth + 8;
        int startY = this.topPos + 5;

        graphics.fill(startX - 4, startY - 4, startX + 170, startY + (offers.size() * 20) + 16, 0xAA000000);
        graphics.drawString(this.font, Component.literal("§eTrade Terdeteksi (" + offers.size() + ")"), startX, startY, 0xFFFFFF);

        int offsetY = startY + 14;
        ItemStack hoveredStack = null;

        for (int i = 0; i < offers.size(); i++) {
            MerchantOffer offer = offers.get(i);
            ItemStack sellItem = offer.getResult();

            graphics.renderItem(sellItem, startX, offsetY - 4);

            String itemName = sellItem.getHoverName().getString();
            if (itemName.length() > 22) {
                itemName = itemName.substring(0, 22) + "...";
            }

            String status = offer.isOutOfStock() ? "§c[Habis]" : "§a[Aktif]";
            graphics.drawString(this.font, Component.literal(status + " §f" + itemName), startX + 20, offsetY, 0xFFFFFF);

            if (mouseX >= startX && mouseX <= startX + 165 && mouseY >= offsetY - 2 && mouseY <= offsetY + 14) {
                hoveredStack = sellItem;
            }

            offsetY += 20;
        }

        if (hoveredStack != null && !hoveredStack.isEmpty()) {
            graphics.renderTooltip(this.font, hoveredStack, mouseX, mouseY);
        }
    }
}
