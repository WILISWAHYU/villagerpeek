package com.wiliz.villagerpeek;

import java.util.List;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.ItemEnchantments;
import net.minecraft.world.item.component.ItemLore;

public class VillagerPeekClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        ItemTooltipCallback.EVENT.register((stack, tooltipContext, tooltipType, lines) -> {
            inspectCustomEnchants(stack, lines);
        });
    }

    private void inspectCustomEnchants(ItemStack stack, List<Component> lines) {
        // Cek enchantment tersimpan (misalnya pada Enchanted Book)
        ItemEnchantments stored = stack.get(DataComponents.STORED_ENCHANTMENTS);
        if (stored != null && !stored.isEmpty()) {
            lines.add(Component.literal("[VillagerPeek] Stored Enchantments:").withStyle(style -> style.withColor(0xFFAA00)));
            stored.entrySet().forEach(entry -> {
                String id = entry.getKey().unwrapKey().map(k -> k.location().toString()).orElse("unknown");
                int level = entry.getIntValue();
                lines.add(Component.literal(" • " + id + " (Lv." + level + ")").withStyle(style -> style.withColor(0x55FFFF)));
            });
        }

        // Cek Lore (banyak plugin custom enchant server menulis info enchant di lore)
        ItemLore lore = stack.get(DataComponents.LORE);
        if (lore != null && !lore.lines().isEmpty()) {
            lines.add(Component.literal("[VillagerPeek] Server / Custom Lore:").withStyle(style -> style.withColor(0x55FF55)));
            for (Component loreLine : lore.lines()) {
                lines.add(Component.literal(" > ").withStyle(style -> style.withColor(0x555555)).append(loreLine));
            }
        }
    }
}
